//
//  ContactItem+CoreDataClass.swift
//  ContactList
//
//  Created by Le Lin on 3/24/17.
//  Copyright © 2017 Le Lin. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(ContactItem)
public class ContactItem: NSManagedObject {

}
